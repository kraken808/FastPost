//
//  CollectionViewCellExtension.swift
//  FastPost
//
//  Created by Murat Merekov on 11.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import UIKit

//extension UICollectionViewCell{
//    func layerSetup(shadowColor: CGColor = CGColor(srgbRed: 0, green: 0, blue: 0, alpha: 0.15), cornerR: CGFloat = 10){
//        self.backgroundColor = .white
//        self.layer.cornerRadius = cornerR
//        self.layer.shadowColor = shadowColor
//        self.layer.shadowRadius = 10
//        self.layer.bounds = self.bounds
//        self.layer.position = self.center
//        self.layer.shadowOpacity = 1
//        self.layer.shadowOffset = CGSize(width: 0, height: 4)
//        self.layer.masksToBounds = false
//    }
//}
