//
//  UIView + Extension.swift
//  FastPost
//
//  Created by Murat Merekov on 06.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import UIKit

extension UIView {
    
    func layerSetup(shadowColor: CGColor = CGColor(srgbRed: 0, green: 0, blue: 0, alpha: 0.15), cornerR: CGFloat = 10){
         self.backgroundColor = .white
         self.layer.cornerRadius = cornerR
         self.layer.shadowColor = shadowColor
         self.layer.shadowRadius = 10
         self.layer.bounds = self.bounds
         self.layer.position = self.center
         self.layer.shadowOpacity = 1
         self.layer.shadowOffset = CGSize(width: 0, height: 4)
         self.layer.masksToBounds = false
     }
    
    var shadow: Bool {
        get {
            return layer.shadowOpacity > 0.0
        }
        set {
            if newValue == true {
                self.addShadow()
            }
        }
    }
    
    var cornerRadius: CGFloat {
        get {
            return self.layer.cornerRadius
        }
        set {
            self.layer.cornerRadius = newValue
            
            // Don't touch the masksToBound property if a shadow is needed in addition to the cornerRadius
            if shadow == false {
                self.layer.masksToBounds = true
            }
        }
    }
    
    
    func addShadow(shadowColor: CGColor = UIColor.black.cgColor,
                   shadowOffset: CGSize = CGSize(width: 1.0, height: 2.0),
                   shadowOpacity: Float = 0.4,
                   shadowRadius: CGFloat = 3.0) {
        layer.shadowColor = shadowColor
        layer.shadowOffset = shadowOffset
        layer.shadowOpacity = shadowOpacity
        layer.shadowRadius = shadowRadius
        layer.masksToBounds = false
    }
}
