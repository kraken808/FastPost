//
//  AllData.swift
//  FastPost
//
//  Created by Murat Merekov on 09.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import Foundation

//struct AllData: Codable {
//    var info:
//}
