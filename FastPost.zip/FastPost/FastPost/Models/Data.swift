//
//  Data.swift
//  FastPost
//
//  Created by Murat Merekov on 23.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import Foundation

struct Data: Codable {
    var item: [Item]
    var event: [Event]
    var variable: [Variable]
}

struct Item: Codable {
    var name: String
    var id: String
    var request: Requestt
}

struct Requestt: Codable {
    var method: String
    var header: [Headerr]
    var body: Body
    var url: String
}

struct Headerr: Codable {
    var key: String
    var value: String
    var type: String
}

struct Body: Codable {
    var mode: String
    var formdata: [Headerr]
}

struct Event: Codable {
    var listen: String
    var script: Script
}

struct Script: Codable {
    var id: String
    var type: String
}

struct Variable: Codable {
    var id: String
    var key: String
    var value: String
}
