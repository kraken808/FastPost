//
//  NetworkManager.swift
//  FastPost
//
//  Created by Murat Merekov on 08.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import UIKit

class NetworkManager {
    
}
