//
//  ServiceProtocol.swift
//  FastPost
//
//  Created by Murat Merekov on 08.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import Foundation

typealias Headers = [String: String]

protocol ServiceProtocol {
    var baseURL: URL { get }
    var path: String { get }
    var method: HTTPMethod { get }
    var task: Task { get }
    var headers: Headers? { get }
    var parametersEncoding: ParametersEncoding { get }
}
