//
//  URLSessionProtocol.swift
//  FastPost
//
//  Created by Murat Merekov on 08.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import Foundation

protocol URLSessionProtocol {
    typealias DataTaskResult = (Data?, URLResponse?, Error?) -> ()
    func dataTask(request: URLRequest, completionHandler: @escaping DataTaskResult) -> URLSessionDataTask
}

extension URLSession: URLSessionProtocol {
    func dataTask(request: URLRequest, completionHandler: @escaping DataTaskResult) -> URLSessionDataTask {
        return dataTask(request: request, completionHandler: completionHandler)
    }
}
