//
//  Users.swift
//  FastPost
//
//  Created by Murat Merekov on 08.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import UIKit

struct Users {
    var name: String
    var image: String
    var from: String
    var to: String
    var date: String
    var rating: String
}
