//
//  LoginViewController.swift
//  FastPost
//
//  Created by Murat Merekov on 16.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import UIKit
import SnapKit

class LoginViewController: UIViewController {
    
    private var fastPostIconImageView: UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "FastPostIcon")
        img.contentMode = .scaleAspectFit
        return img
    }()
    
    private lazy var phoneNumberTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Номер телефона"
        text.cornerRadius = 25
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.textColor = UIColor(red: 0.459, green: 0.549, blue: 0.612, alpha: 0.6)
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
        return text
    }()
    
    private lazy var passwordTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Пароль"
        text.cornerRadius = 25
        text.textColor = UIColor(red: 0.459, green: 0.549, blue: 0.612, alpha: 0.6)
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
        return text
    }()
    
    private lazy var loginButoon: UIButton = {
        let bttn = UIButton()
        bttn.setTitle("Войти", for: .normal)
        bttn.titleLabel?.font = UIFont(name: "FiraSans-Bold", size: 15)
        bttn.setTitleColor(.white, for: .normal)
        bttn.cornerRadius = 25
        bttn.clipsToBounds = false
        bttn.backgroundColor = UIColor(red: 35/255, green: 104/255, blue: 152/255, alpha: 1)
        bttn.layer.shadowRadius = 4.0
        
        bttn.layer.shadowColor = UIColor.gray.cgColor
        bttn.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        bttn.layer.shadowOpacity = 0.3
        bttn.translatesAutoresizingMaskIntoConstraints = false
        bttn.addTarget(self, action: #selector(loginButoonClicked), for: .touchUpInside)
        return bttn
    }()
    
    private lazy var textFieldsVerticalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .vertical
        stk.spacing = 15
        stk.distribution = .fillProportionally
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var outerVerticalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .center
        stk.axis = .vertical
        stk.spacing = 27
        stk.distribution = .fill
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var bottomVerticalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .vertical
        stk.spacing = 1
        stk.distribution = .fillProportionally
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var labelHorizontalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .horizontal
        stk.spacing = 10
        stk.distribution = .fillProportionally
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var labelsVerticalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .vertical
        stk.spacing = 10
        stk.distribution = .fillProportionally
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var forgotPasswordButton: UIButton = {
        let bttn = UIButton()
        bttn.setTitle("Забыли пароль?", for: .normal)
        bttn.titleLabel?.font = UIFont(name: "FiraSans-Medium", size: 13)
        bttn.setTitleColor(UIColor(red: 0.459, green: 0.549, blue: 0.612, alpha: 1), for: .normal)
        bttn.addTarget(self, action: #selector(forgotPasswordButtonClicked), for: .touchUpInside)
        return bttn
    }()
    
    private lazy var registrationButton: UIButton = {
        let bttn = UIButton()
        bttn.setTitle("Регистрация", for: .normal)
        bttn.titleLabel?.font = UIFont(name: "FiraSans-Medium", size: 13)
        bttn.setTitleColor(UIColor(red: 0.459, green: 0.549, blue: 0.612, alpha: 1), for: .normal)
        bttn.addTarget(self, action: #selector(registrationButtonClicked), for: .touchUpInside)
        return bttn
    }()
    
    private lazy var haventAccountLabel: UILabel = {
       let label = UILabel()
        label.font = UIFont(name: "FiraSans-Regular", size: 13)
        label.textColor = UIColor(red: 0.459, green: 0.549, blue: 0.612, alpha: 1)
        label.text = "Нет аккаунта?"
        return label
    }()
    
    private lazy var loginLabel: UILabel = {
       let label = UILabel()
        label.font = UIFont(name: "FiraSans-Bold", size: 16)
        label.textColor = UIColor(red: 0.969, green: 0.569, blue: 0.561, alpha: 1)
        label.text = "Вход"
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addSubViews()
        setupConstraints()
    }
    
    private func addSubViews() {
        
        view.addSubview(outerVerticalStackView)
//        view.addSubview(fastPostIconImageView)
        
        textFieldsVerticalStackView.addArrangedSubview(phoneNumberTextField)
        textFieldsVerticalStackView.addArrangedSubview(passwordTextField)
        textFieldsVerticalStackView.addArrangedSubview(loginButoon)
        
        labelHorizontalStackView.addArrangedSubview(haventAccountLabel)
        labelHorizontalStackView.addArrangedSubview(registrationButton)
        
        bottomVerticalStackView.addArrangedSubview(forgotPasswordButton)
        bottomVerticalStackView.addArrangedSubview(labelHorizontalStackView)
        
        outerVerticalStackView.addArrangedSubview(fastPostIconImageView)
        outerVerticalStackView.addArrangedSubview(loginLabel)
        outerVerticalStackView.addArrangedSubview(textFieldsVerticalStackView)
        outerVerticalStackView.addArrangedSubview(bottomVerticalStackView)
        
    }
    
    private func setupConstraints() {
        outerVerticalStackView.snp.makeConstraints { (make) in
            make.centerX.centerY.equalToSuperview()
            make.left.right.equalToSuperview().inset(25)
        }
        
        phoneNumberTextField.snp.makeConstraints { (make) in
            make.height.equalTo(50)
        }
        
        textFieldsVerticalStackView.snp.makeConstraints { (make) in
            make.right.left.equalToSuperview()
//            make.height.equalTo(180)
        }
        
        passwordTextField.snp.makeConstraints { (make) in
            make.height.equalTo(50)
        }
        
        loginButoon.snp.makeConstraints { (make) in
            make.height.equalTo(50)
        }
        
        fastPostIconImageView.snp.makeConstraints { (make) in
            make.width.equalTo(159)
            make.height.equalTo(124)
        }
    }
    
    @objc private func loginButoonClicked() {
        
    }
    
    @objc private func forgotPasswordButtonClicked() {
        let vc = RestorePhoneNumberViewController()
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
    }
    
    @objc private func registrationButtonClicked() {
        let vc = RegistrationViewController()
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
    }
}

// MARK: - SwiftUI
import SwiftUI

struct LoginVCProvider: PreviewProvider {
    
    static var previews: some View {
        return ContentView()
    }
    
    struct ContentView: UIViewControllerRepresentable {
        
        func makeUIViewController(context: Context) -> LoginViewController {
            return LoginViewController()
        }
        
        func updateUIViewController(_ uiViewController: LoginViewController, context: Context) {
            //
        }
    }
}
