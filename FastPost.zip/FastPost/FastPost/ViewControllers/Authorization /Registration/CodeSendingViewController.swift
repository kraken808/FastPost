//
//  CodeSendingViewController.swift
//  FastPost
//
//  Created by Murat Merekov on 18.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import UIKit
import SnapKit

class CodeSendingViewController: UIViewController {
    
    private lazy var containerView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.cornerRadius = 10
        return view
    }()
    
    private lazy var firstCellTextField: UITextField = {
        let cell = UITextField()
        cell.cornerRadius = 3.58
        cell.layer.backgroundColor = UIColor(red: 0.446, green: 0.573, blue: 0.663, alpha: 0.3).cgColor
        return cell
    }()
    
    private lazy var secondCellTextField: UITextField = {
        let cell = UITextField()
        cell.cornerRadius = 3.58
        cell.layer.backgroundColor = UIColor(red: 0.446, green: 0.573, blue: 0.663, alpha: 0.3).cgColor
        return cell
    }()
    
    private lazy var thirdCellTextField: UITextField = {
        let cell = UITextField()
        cell.cornerRadius = 3.58
        cell.layer.backgroundColor = UIColor(red: 0.446, green: 0.573, blue: 0.663, alpha: 0.3).cgColor
        return cell
    }()
    
    private lazy var fourthCellTextField: UITextField = {
        let cell = UITextField()
        cell.cornerRadius = 3.58
        cell.layer.backgroundColor = UIColor(red: 0.446, green: 0.573, blue: 0.663, alpha: 0.3).cgColor
        return cell
    }()
    
    private lazy var cellsStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .horizontal
        stk.spacing = 5
        stk.distribution = .fill
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var buttonsStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .horizontal
        stk.spacing = 5
        stk.distribution = .fill
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var verticalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .leading
        stk.axis = .vertical
        stk.spacing = 10
        stk.distribution = .fillProportionally
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Код"
        label.font = UIFont(name: "FiraSans-Bold", size: 18)
        label.textColor = UIColor(red: 0.446, green: 0.573, blue: 0.663, alpha: 1)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var messageLabel: UILabel = {
        let label = UILabel()
        label.text = "До отправки следующего кода: 59"
        label.numberOfLines = 1
        label.textAlignment = .center
        label.font = UIFont(name: "FiraSans-Regular", size: 14)
        label.textColor = UIColor(red: 0.446, green: 0.573, blue: 0.663, alpha: 1)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var okButton: UIButton = {
        let bttn = UIButton()
        bttn.setTitle("ОК", for: .normal)
        bttn.setTitleColor(UIColor(red: 247/255, green: 145/255, blue: 143/255, alpha: 1), for: .normal)
        bttn.titleLabel?.font = UIFont(name: "FiraSans-Medium", size: 13)
        bttn.addTarget(self, action: #selector(okButtonClicked), for: .touchUpInside)
        return bttn
    }()
    
    private lazy var changeNumberButton: UIButton = {
        let bttn = UIButton()
        bttn.setTitle("ИЗМЕНИТЬ НОМЕР", for: .normal)
        bttn.setTitleColor(UIColor(red: 247/255, green: 145/255, blue: 143/255, alpha: 1), for: .normal)
        bttn.titleLabel?.font = UIFont(name: "FiraSans-Medium", size: 13)
        bttn.addTarget(self, action: #selector(changeNumberButtonClicked), for: .touchUpInside)
        return bttn
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 82/255, green: 78/255, blue: 78/255, alpha: 0.5)
        addSubviews()
        setupConstraints()
    }
    
    private func addSubviews() {
        view.addSubview(containerView)
        
        containerView.addSubview(okButton)
        containerView.addSubview(verticalStackView)
        containerView.addSubview(changeNumberButton)
        containerView.addSubview(buttonsStackView)
        
        cellsStackView.addArrangedSubview(firstCellTextField)
        cellsStackView.addArrangedSubview(secondCellTextField)
        cellsStackView.addArrangedSubview(thirdCellTextField)
        cellsStackView.addArrangedSubview(fourthCellTextField)
        
        verticalStackView.addArrangedSubview(titleLabel)
        verticalStackView.addArrangedSubview(cellsStackView)
        verticalStackView.addArrangedSubview(messageLabel)
        
        buttonsStackView.addArrangedSubview(changeNumberButton)
        buttonsStackView.addArrangedSubview(okButton)

    }
    
    private func setupConstraints() {
        
        buttonsStackView.snp.makeConstraints { (make) in
            make.right.bottom.equalToSuperview().inset(7)
        }
        
        containerView.snp.makeConstraints { (make) in
            make.centerY.centerX.equalToSuperview()
            make.height.equalTo(179)
            make.width.equalTo(280)
        }
        
        firstCellTextField.snp.makeConstraints { (make) in
            make.height.equalTo(40)
            make.width.equalTo(38)
        }
        
        secondCellTextField.snp.makeConstraints { (make) in
            make.height.equalTo(40)
            make.width.equalTo(38)
        }
        
        thirdCellTextField.snp.makeConstraints { (make) in
            make.height.equalTo(40)
            make.width.equalTo(38)
        }
        
        fourthCellTextField.snp.makeConstraints { (make) in
            make.height.equalTo(40)
            make.width.equalTo(38)
        }
        
        verticalStackView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.right.equalToSuperview().inset(24)
        }
        messageLabel.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
        }
        
        
    }
    
    @objc private func okButtonClicked() {
        let vc = FinishRegistrationAlertViewController()
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overCurrentContext
        self.present(vc, animated: true)
    }
    
    @objc private func changeNumberButtonClicked() {
        self.dismiss(animated: true, completion: nil)
    }
    
}

// MARK: - SwiftUI
import SwiftUI

struct CodeSendingVCProvider: PreviewProvider {
    
    static var previews: some View {
        return ContentView()
    }
    
    struct ContentView: UIViewControllerRepresentable {
        
        func makeUIViewController(context: Context) -> CodeSendingViewController {
            return CodeSendingViewController()
        }
        
        func updateUIViewController(_ uiViewController: CodeSendingViewController, context: Context) {
            //
        }
    }
}
