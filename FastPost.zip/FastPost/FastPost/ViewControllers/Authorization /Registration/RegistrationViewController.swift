//
//  Registration.swift
//  FastPost
//
//  Created by Murat Merekov on 17.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import UIKit

class RegistrationViewController: UIViewController,ConfiguringVC {
    
    private lazy var navbarView: UIView = {
       let view = UIView()
        return view
    }()
    
    private lazy var titleLabel: UILabel = {
       let label = UILabel()
        label.text = "Регистрация"
        label.textColor = UIColor(red: 0.969, green: 0.569, blue: 0.561, alpha: 1)
        label.font = UIFont(name: "FiraSans-Bold", size: 16)
        return label
    }()
    
    private lazy var backButton: UIButton = {
        let bttn = UIButton()
        bttn.setImage(UIImage(named: "Back"), for: .normal)
        bttn.addTarget(self, action: #selector(backButtonClicked), for: .touchUpInside)
        return bttn
    }()
    
    private lazy var nameTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Имя"
        text.cornerRadius = 25
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.textColor = UIColor(red: 0.459, green: 0.549, blue: 0.612, alpha: 0.6)
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
        return text
    }()
    
    private lazy var surnameTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Фамилия"
        text.cornerRadius = 25
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.textColor = UIColor(red: 0.459, green: 0.549, blue: 0.612, alpha: 0.6)
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
        return text
    }()
    
    private lazy var dateOfBirthTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Дата рождения"
        text.cornerRadius = 25
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.textColor = UIColor(red: 0.459, green: 0.549, blue: 0.612, alpha: 0.6)
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
        return text
    }()
    
    private lazy var phoneNumberTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Номер телефона"
        text.cornerRadius = 25
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.textColor = UIColor(red: 0.459, green: 0.549, blue: 0.612, alpha: 0.6)
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
        return text
    }()
    
    private lazy var passwordTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Пароль"
        text.cornerRadius = 25
        text.textColor = UIColor(red: 0.459, green: 0.549, blue: 0.612, alpha: 0.6)
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
        return text
    }()
    
    private lazy var infoLabel: UILabel = {
       let label = UILabel()
        label.font = UIFont(name: "FiraSans-Medium", size: 16)
        label.textColor = UIColor(red: 0.459, green: 0.549, blue: 0.612, alpha: 1)
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        label.text = "Прикрепите фотографии документа удостоверяющий вашу личность с обеих сторон"
        return label
    }()
    
    private lazy var attachFileTextField: UITextField = {
        let text = UITextField()
        text.placeholder = ""
        text.cornerRadius = 10
        text.textColor = UIColor(red: 0.459, green: 0.549, blue: 0.612, alpha: 0.6)
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
        text.delegate = self
        return text
    }()
    
    private lazy var registrationButoon: UIButton = {
        let bttn = UIButton()
        bttn.setTitle("Войти", for: .normal)
        bttn.titleLabel?.font = UIFont(name: "FiraSans-Bold", size: 15)
        bttn.setTitleColor(.white, for: .normal)
        bttn.cornerRadius = 20
        bttn.clipsToBounds = false
        bttn.backgroundColor = UIColor(red: 35/255, green: 104/255, blue: 152/255, alpha: 1)
        bttn.layer.shadowRadius = 4.0
        
        bttn.layer.shadowColor = UIColor.gray.cgColor
        bttn.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        bttn.layer.shadowOpacity = 0.3
        bttn.translatesAutoresizingMaskIntoConstraints = false
        bttn.addTarget(self, action: #selector(registrationButoonClicked), for: .touchUpInside)
        return bttn
    }()
    
    private lazy var firstVerticalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .center
        stk.axis = .vertical
        stk.spacing = 10
        stk.distribution = .fill
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var secondVerticalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .center
        stk.axis = .vertical
        stk.spacing = 10
        stk.distribution = .fill
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var thirdVerticalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .center
        stk.axis = .vertical
        stk.spacing = 20
        stk.distribution = .fill
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = false
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.backgroundColor = .clear
            title = "Registration"
        addSubviews()
        setupConstraints()
    }
    
    internal func addSubviews() {
        navbarView.addSubview(backButton)
        navbarView.addSubview(titleLabel)
        
        firstVerticalStackView.addArrangedSubview(navbarView)
        firstVerticalStackView.addArrangedSubview(nameTextField)
        firstVerticalStackView.addArrangedSubview(surnameTextField)
        firstVerticalStackView.addArrangedSubview(dateOfBirthTextField)
        firstVerticalStackView.addArrangedSubview(phoneNumberTextField)
        firstVerticalStackView.addArrangedSubview(passwordTextField)
        
        secondVerticalStackView.addArrangedSubview(infoLabel)
        secondVerticalStackView.addArrangedSubview(attachFileTextField)
        
        thirdVerticalStackView.addArrangedSubview(firstVerticalStackView)
        thirdVerticalStackView.addArrangedSubview(secondVerticalStackView)
        thirdVerticalStackView.addArrangedSubview(registrationButoon)
        
        view.addSubview(thirdVerticalStackView)
    }
    
    internal func setupConstraints() {
        
        navbarView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.height.equalTo(54)
        }
        
        backButton.snp.makeConstraints { (make) in
            make.left.centerY.equalToSuperview()
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.centerY.centerX.equalToSuperview()
        }
        
        nameTextField.snp.makeConstraints { (make) in
            make.height.equalTo(54)
            make.right.left.equalToSuperview()
        }
        
        surnameTextField.snp.makeConstraints { (make) in
            make.height.equalTo(54)
            make.right.left.equalToSuperview()
        }
        
        dateOfBirthTextField.snp.makeConstraints { (make) in
            make.height.equalTo(54)
            make.right.left.equalToSuperview()
        }
        
        phoneNumberTextField.snp.makeConstraints { (make) in
            make.height.equalTo(54)
            make.right.left.equalToSuperview()
        }
        
        passwordTextField.snp.makeConstraints { (make) in
            make.height.equalTo(54)
            make.right.left.equalToSuperview()
        }
        
        attachFileTextField.snp.makeConstraints { (make) in
            make.height.equalTo(140)
            make.right.left.equalToSuperview()
        }
        
        registrationButoon.snp.makeConstraints { (make) in
            make.height.equalTo(43)
            make.right.left.equalToSuperview()
        }
        
        firstVerticalStackView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
        }
        
        secondVerticalStackView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
        }
        
        thirdVerticalStackView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview().inset(13)
            make.top.equalToSuperview()
        }
        
        
    }
    
    @objc private func registrationButoonClicked() {
        let vc = CodeSendingViewController()
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overCurrentContext
        self.present(vc, animated: true)
    }
    
    @objc private func backButtonClicked() {
        self.dismiss(animated: true, completion: nil)
    }
}

extension RegistrationViewController: UITextFieldDelegate {
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = .photoLibrary
        present(imagePickerController, animated: true, completion: nil)
        return false
    }
}

extension RegistrationViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        picker.dismiss(animated: true, completion: nil)
        guard let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else { return }
//        fullImageView.circleImageView.image = image
    }
}

// MARK: - SwiftUI
import SwiftUI

struct RegistrationVCProvider: PreviewProvider {
    
    static var previews: some View {
        return ContentView()
    }
    
    struct ContentView: UIViewControllerRepresentable {
        
        func makeUIViewController(context: Context) -> RegistrationViewController {
            return RegistrationViewController()
        }
        
        func updateUIViewController(_ uiViewController: RegistrationViewController, context: Context) {
            //
        }
    }
}
