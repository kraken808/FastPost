//
//  ChooseViewController.swift
//  FastPost
//
//  Created by Murat Merekov on 05.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import UIKit
import SnapKit

class ChooseViewController: UIViewController {
    
    private lazy var sendPostButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "WantSent"), for: .normal)
        button.addTarget(self, action: #selector(sendButtonClicked), for: .touchUpInside)
        return button
    }()
    
    private lazy var earnMoneyButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "WantEarn"), for: .normal)
        button.addTarget(self, action: #selector(earnButtonClicked), for: .touchUpInside)
        return button
    }()
    
    private lazy var stackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .vertical
        stk.distribution = .fillProportionally
        return stk
    }()
    
    private lazy var leftImageView: UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "RightArrow")
        return img
    }()
    
    private lazy var rightImageView: UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "LeftArrow")
        return img
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        addSubViews()
        setupConstraints()
    }
    
    private func addSubViews() {
        view.addSubview(stackView)
        stackView.addArrangedSubview(sendPostButton)
        stackView.addArrangedSubview(earnMoneyButton)
        view.addSubview(leftImageView)
        view.addSubview(rightImageView)
    }

    private func setupConstraints() {
        stackView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
        }
        
        leftImageView.snp.makeConstraints { (make) in
            make.bottom.equalTo(stackView.snp.top).offset(35)
            make.left.equalToSuperview()
            
        }
        
        rightImageView.snp.makeConstraints { (make) in
            make.bottom.equalTo(stackView.snp.top).offset(-20)
            make.right.equalToSuperview()
        }
    }
    
    @objc func sendButtonClicked() {
        let gotoVC = MainPageViewController()
        gotoVC.modalTransitionStyle = .crossDissolve
        gotoVC.modalPresentationStyle = .fullScreen
        self.present(gotoVC, animated: true)
    }
    
    @objc func earnButtonClicked() {
        let gotoVC = PostSendRequestViewController()
        gotoVC.modalTransitionStyle = .crossDissolve
        gotoVC.modalPresentationStyle = .fullScreen
        self.present(gotoVC, animated: true)
    }

}
