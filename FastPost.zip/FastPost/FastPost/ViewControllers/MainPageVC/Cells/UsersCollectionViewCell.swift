//
//  CollectionViewCell.swift
//  FastPost
//
//  Created by Murat Merekov on 07.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import UIKit
import SnapKit

class UsersCollectionViewCell: UICollectionViewCell, ConfiguringCell {
    
    static var reuseIdentifier: String = "UsersCell"
    
    typealias T = Users
    
    private lazy var avatarImageView: UIImageView = {
        let image = UIImageView(frame: CGRect(x: 0, y: 0, width: 43, height: 43))
        image.cornerRadius = 10
        image.contentMode = .scaleAspectFill
        image.makeRounded()
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    private lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 35/255, green: 104/255, blue: 152/255, alpha: 1)
        label.font = UIFont(name: "FiraSans-Regular", size: 14)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var fromCityLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 35/255, green: 104/255, blue: 152/255, alpha: 1)
        label.font = UIFont(name: "FiraSans-Bold", size: 18)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var toCityLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 35/255, green: 104/255, blue: 152/255, alpha: 1)
        label.font = UIFont(name: "FiraSans-Bold", size: 18)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var planeIconImageView: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "Plane")
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    private lazy var starIcon1ImageView: UIImageView = {
        let image = UIImageView(frame: CGRect(x: 0, y: 0, width: 13, height: 13))
        image.snp.makeConstraints { (make) in
            make.height.width.equalTo(13)
        }
        image.image = UIImage(systemName: "star.fill")
        image.contentMode = .scaleAspectFit
        image.clipsToBounds = true
        image.tintColor = UIColor(red: 255/255, green: 193/255, blue: 7/255, alpha: 1)
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    private lazy var starIcon2ImageView: UIImageView = {
        let image = UIImageView(frame: CGRect(x: 0, y: 0, width: 13, height: 13))
        image.snp.makeConstraints { (make) in
            make.height.width.equalTo(13)
        }
        image.clipsToBounds = true
        image.image = UIImage(systemName: "star.fill")
        image.tintColor = UIColor(red: 255/255, green: 193/255, blue: 7/255, alpha: 1)
        image.contentMode = .scaleAspectFit
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    private lazy var starIcon3ImageView: UIImageView = {
        let image = UIImageView(frame: CGRect(x: 0, y: 0, width: 13, height: 13))
        image.snp.makeConstraints { (make) in
            make.height.width.equalTo(13)
        }
        image.clipsToBounds = true
        image.image = UIImage(systemName: "star.fill")
        image.tintColor = UIColor(red: 255/255, green: 193/255, blue: 7/255, alpha: 1)
        image.contentMode = .scaleAspectFit
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    private lazy var starIcon4ImageView: UIImageView = {
        let image = UIImageView(frame: CGRect(x: 0, y: 0, width: 13, height: 13))
        image.snp.makeConstraints { (make) in
            make.height.width.equalTo(13)
        }
        image.clipsToBounds = true
        image.image = UIImage(systemName: "star.fill")
        image.tintColor = UIColor(red: 255/255, green: 193/255, blue: 7/255, alpha: 1)
        image.contentMode = .scaleAspectFit
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    private lazy var starIcon5ImageView: UIImageView = {
        let image = UIImageView(frame: CGRect(x: 0, y: 0, width: 13, height: 13))
        image.snp.makeConstraints { (make) in
            make.height.width.equalTo(13)
        }
        image.clipsToBounds = true
        image.image = UIImage(systemName: "star.fill")
        image.tintColor = UIColor(red: 255/255, green: 193/255, blue: 7/255, alpha: 1)
        image.contentMode = .scaleAspectFit
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    private lazy var boxIconImageView: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "Box")
        image.contentMode = .scaleAspectFit
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    private lazy var ratingLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 35/255, green: 104/255, blue: 152/255, alpha: 1)
        label.font = UIFont(name: "FiraSans-Regular", size: 11)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var weightLabel: UILabel = {
        let label = UILabel()
        label.text = "2.5"
        label.font = UIFont(name: "FiraSans-Medium", size: 14)
        label.textColor = UIColor(red: 196/255, green: 141/255, blue: 105/255, alpha: 1)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var kgLabel: UILabel = {
        let kg = UILabel()
        kg.text = "КГ"
        kg.textColor = UIColor(red: 196/255, green: 141/255, blue: 105/255, alpha: 1)
        kg.font = UIFont(name: "FiraSans-Medium", size: 8)
        kg.translatesAutoresizingMaskIntoConstraints = false
        return kg
    }()
    
    private lazy var dateLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(red: 35/255, green: 104/255, blue: 152/255, alpha: 1)
        label.font = UIFont(name: "FiraSans-Regular", size: 14)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var chatButton: UIButton = {
        let bttn = UIButton()
        bttn.autoresizingMask = [.flexibleLeftMargin, .flexibleBottomMargin]
        bttn.setImage(UIImage(named: "Chat"), for: .normal)
        bttn.translatesAutoresizingMaskIntoConstraints = false
        return bttn
    }()
    
    private lazy var nameRatingStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .vertical
        stk.spacing = -4
        stk.distribution = .fillEqually
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var avatarNameRatingStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .horizontal
        stk.spacing = 5
        stk.distribution = .fill
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var ratingStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .horizontal
        
        stk.distribution = .fillProportionally
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var weightKgStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .lastBaseline
        stk.axis = .horizontal
        stk.spacing = 3
        stk.distribution = .fillProportionally
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var directionStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .center
        stk.axis = .horizontal
        stk.spacing = -5
        stk.distribution = .equalSpacing
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var directionDateStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.translatesAutoresizingMaskIntoConstraints = false
        stk.axis = .vertical
        stk.spacing = 1
        stk.distribution = .equalSpacing
        return stk
    }()
    
    private lazy var weightBoxStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .center
        stk.translatesAutoresizingMaskIntoConstraints = false
        stk.axis = .vertical
        stk.spacing = -5
        stk.distribution = .fillEqually
        return stk
    }()
    
    private lazy var weightBoxDirectionDateStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .horizontal
        stk.spacing = 10
        stk.distribution = .fillProportionally
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addViews()
        setupConstraints()
        contentView.layerSetup()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func bind(data: Users) {
        nameLabel.text = data.name
        avatarImageView.image = UIImage(named: data.image)
        dateLabel.text = data.date
        ratingLabel.text = data.rating
        fromCityLabel.text = data.from
        toCityLabel.text = data.to
      
    }
    
    func addViews() {
        ratingStackView.addArrangedSubview(starIcon1ImageView)
        ratingStackView.addArrangedSubview(starIcon2ImageView)
        ratingStackView.addArrangedSubview(starIcon3ImageView)
        ratingStackView.addArrangedSubview(starIcon4ImageView)
        ratingStackView.addArrangedSubview(starIcon5ImageView)
        ratingStackView.addArrangedSubview(ratingLabel)
        
        nameRatingStackView.addArrangedSubview(nameLabel)
        nameRatingStackView.addArrangedSubview(ratingStackView)
        
        avatarNameRatingStackView.addArrangedSubview(avatarImageView)
        avatarNameRatingStackView.addArrangedSubview(nameRatingStackView)
        
        directionStackView.addArrangedSubview(fromCityLabel)
        directionStackView.addArrangedSubview(planeIconImageView)
        directionStackView.addArrangedSubview(toCityLabel)
        
        directionDateStackView.addArrangedSubview(directionStackView)
        directionDateStackView.addArrangedSubview(dateLabel)
        
        weightKgStackView.addArrangedSubview(weightLabel)
        weightKgStackView.addArrangedSubview(kgLabel)
        
        weightBoxStackView.addArrangedSubview(weightKgStackView)
        weightBoxStackView.addArrangedSubview(boxIconImageView)
        
        weightBoxDirectionDateStackView.addArrangedSubview(weightBoxStackView)
        weightBoxDirectionDateStackView.addArrangedSubview(directionDateStackView)
        
        contentView.addSubview(avatarNameRatingStackView)
        contentView.addSubview(weightBoxDirectionDateStackView)
        contentView.addSubview(chatButton)
    }
    
    func setupConstraints() {
        
        avatarImageView.snp.makeConstraints { (make) in
            make.width.height.equalTo(43)
        }
        
//        ratingStackView.snp.makeConstraints { (make) in
//            make.width.equalTo(20)
//            make.height.equalTo(<#T##other: ConstraintRelatableTarget##ConstraintRelatableTarget#>)
//        }
        
//        starIcon1ImageView.snp.makeConstraints { (make) in
//            make.height.width.equalTo(13)
//        }
//        starIcon2ImageView.snp.makeConstraints { (make) in
//            make.height.width.equalTo(13)
//        }
//        starIcon3ImageView.snp.makeConstraints { (make) in
//            make.height.width.equalTo(13)
//        }
//        starIcon4ImageView.snp.makeConstraints { (make) in
//            make.height.width.equalTo(13)
//        }
//        starIcon5ImageView.snp.makeConstraints { (make) in
//            make.height.width.equalTo(13)
//        }
        
        avatarNameRatingStackView.snp.makeConstraints { (make) in
            make.top.left.equalToSuperview().inset(15)
            make.width.equalTo(200)
            make.height.equalTo(43)
        }
        
        directionDateStackView.snp.makeConstraints { (make) in
            make.height.equalTo(10)
        }
        
        weightBoxDirectionDateStackView.snp.makeConstraints { (make) in
            make.top.equalTo(avatarNameRatingStackView.snp.bottom).offset(15)
            make.left.equalToSuperview().inset(20)
            make.height.equalTo(50)
            make.right.equalTo(-150)
        }
        
        chatButton.snp.makeConstraints { (make) in
            make.height.width.equalTo(28)
            make.bottom.right.equalToSuperview().inset(15)
        }
    }
    
}


