//
//  MainPageViewController.swift
//  FastPost
//
//  Created by Murat Merekov on 06.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import UIKit
import SnapKit

class MainPageViewController: UIViewController {
    
    private lazy var imageView: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "textIm")
        return image
    }()
    
    private lazy var calendarButton: UIButton = {
        let bttn = UIButton()
        bttn.setImage(UIImage(named: "Calendar"), for: .normal)
        return bttn
    }()
    
    private lazy var recomendedLabel: UILabel = {
        let label = UILabel()
        label.text = "Возможно, вам подойдут эти маршруты"
        label.font = UIFont(name: "FiraSans-Bold", size: 15)
        label.textColor = UIColor(red: 114/255, green: 146/255, blue: 169/255, alpha: 1)
        return label
    }()
    
    private lazy var fromCityTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Откуда"
        text.cornerRadius = 25
        text.clipsToBounds = false
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        return text
    }()
    
    private lazy var toCityTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Куда"
        text.cornerRadius = 25
        text.clipsToBounds = false
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        return text
    }()
    
    private lazy var dateTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Дата"
        text.cornerRadius = 25
        text.clipsToBounds = false
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4.0
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        return text
    }()
    
    private lazy var findButoon: UIButton = {
        let bttn = UIButton()
        bttn.setTitle("Поиск", for: .normal)
        bttn.titleLabel?.font = UIFont(name: "FiraSans-Bold", size: 15)
        bttn.setTitleColor(UIColor(red: 35/255, green: 104/255, blue: 152/255, alpha: 1), for: .normal)
        bttn.cornerRadius = 25
        bttn.clipsToBounds = false
        bttn.backgroundColor = UIColor.white
        bttn.layer.shadowRadius = 4.0
        bttn.layer.borderColor = UIColor.gray.cgColor
        bttn.layer.shadowColor = UIColor.gray.cgColor
        bttn.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        bttn.layer.shadowOpacity = 0.3
        return bttn
    }()
    
    private lazy var verticalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .vertical
        stk.spacing = 10
        stk.distribution = .fillEqually
        return stk
    }()
    
    private lazy var horizontalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .horizontal
        stk.spacing = 10
        stk.distribution = .fillProportionally
        return stk
    }()
    
    private lazy var collectionView: UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.scrollDirection = .vertical
        let cv = UICollectionView(frame: .zero, collectionViewLayout: flowLayout)
        cv.backgroundColor = .white
        cv.register(UsersCollectionViewCell.self,
                    forCellWithReuseIdentifier: UsersCollectionViewCell.reuseIdentifier)
        return cv
    }()
    
    private lazy var temp: [Users] = {
        let user1 = Users(name: "Thomas Shelby",
                          image: "ava1",
                          from: "Алматы",
                          to: "Караганды",
                          date: "21 сентябрь - 13:00",
                          rating: "4.5")
        let user2 = Users(name: "Аргоня Кайрат",
                          image: "ava2",
                          from: "Алматы",
                          to: "Караганды",
                          date: "21 сентябрь - 13:00",
                          rating: "4.5")
        
        var temp = [user1,user2]
        return temp
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setupCollection()
        addSubViews()
        setupConstraints()
        
    }
    
    private func setupCollection() {
        
    
        collectionView.delegate = self
        collectionView.dataSource = self
    }
    
    private func addSubViews() {
    
        
        horizontalStackView.translatesAutoresizingMaskIntoConstraints = false
        verticalStackView.translatesAutoresizingMaskIntoConstraints = false
        findButoon.translatesAutoresizingMaskIntoConstraints = false
        dateTextField.translatesAutoresizingMaskIntoConstraints = false
        fromCityTextField.translatesAutoresizingMaskIntoConstraints = false
        toCityTextField.translatesAutoresizingMaskIntoConstraints = false
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(verticalStackView)
        view.addSubview(imageView)
        view.addSubview(recomendedLabel)
        view.addSubview(collectionView)
        
        dateTextField.addSubview(calendarButton)
        horizontalStackView.addArrangedSubview(dateTextField)
        horizontalStackView.addArrangedSubview(findButoon)
        verticalStackView.addArrangedSubview(fromCityTextField)
        verticalStackView.addArrangedSubview(toCityTextField)
        verticalStackView.addArrangedSubview(horizontalStackView)
        
    }
    
    private func setupConstraints() {
        
        imageView.snp.makeConstraints { (make) in
            make.top.equalTo(60)
            make.left.equalTo(30)
        }
        
        verticalStackView.snp.makeConstraints { (make) in
            make.top.equalTo(imageView).inset(30)
            make.left.equalToSuperview().inset(15)
            make.right.equalToSuperview().inset(15)
            make.height.equalTo(170)
        }
        
        fromCityTextField.snp.makeConstraints { (make) in
            make.height.equalTo(50)
        }
        
        toCityTextField.snp.makeConstraints { (make) in
            make.height.equalTo(50)
        }
        
//        dateTextField.snp.makeConstraints { (make) in
//            make.width.equalTo(150)
//        }
        
        horizontalStackView.snp.makeConstraints { (make) in
            make.height.equalTo(50)
        }
        
        recomendedLabel.snp.makeConstraints { (make) in
            make.top.equalTo(verticalStackView.snp.bottom).offset(20)
            make.left.equalToSuperview().inset(30)
        }
        
        findButoon.snp.makeConstraints { (make) in
            make.width.equalTo(100)
        }
        
        calendarButton.snp.makeConstraints { (make) in
            make.right.equalTo(dateTextField.snp.right).offset(-40)
            make.centerY.equalToSuperview()
        }
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(recomendedLabel.snp.bottom).offset(10)
            make.left.right.bottom.equalToSuperview()
        }
        
    }
}

extension MainPageViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return temp.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: UsersCollectionViewCell.reuseIdentifier,
                                                            for: indexPath) as? UsersCollectionViewCell else {
                                                                assertionFailure("Cannot dequeue collectionView cell")
                                                                return UICollectionViewCell()
        }
        cell.bind(data: temp[indexPath.row])
//        cell.backgroundColor = .yellow

        return cell
    }


}

extension MainPageViewController: UICollectionViewDelegate {

}

extension MainPageViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.width-26, height: collectionView.frame.width/2.9)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0)
    }
}


// MARK: - SwiftUI
import SwiftUI

struct MainPageVCProvider: PreviewProvider {

static var previews: some View {
        return ContentView()
    }
    
    struct ContentView: UIViewControllerRepresentable {
        
        func makeUIViewController(context: Context) -> MainPageViewController {
            return MainPageViewController()
        }
        
        func updateUIViewController(_ uiViewController: MainPageViewController, context: Context) {
            //
        }
    }
}
