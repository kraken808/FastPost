//
//  FinishAlertViewController.swift
//  FastPost
//
//  Created by Murat Merekov on 16.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import UIKit
import SnapKit

class FinishAlertViewController: UIViewController {
    
    private lazy var alertView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.cornerRadius = 10
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "Спасибо!"
        label.font = UIFont(name: "FiraSans-Bold", size: 18)
        label.textColor = UIColor(red: 0.446, green: 0.573, blue: 0.663, alpha: 1)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var messageLabel: UILabel = {
        let label = UILabel()
        label.text = "Ваша заявка видна всем исполнителям!"
        label.numberOfLines = 0
        label.font = UIFont(name: "FiraSans-Regular", size: 14)
        label.textColor = UIColor(red: 0.446, green: 0.573, blue: 0.663, alpha: 1)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var continueButton: UIButton = {
        let bttn = UIButton()
        bttn.setTitle("ПРОДОЛЖИТЬ", for: .normal)
        bttn.setTitleColor(UIColor(red: 247/255, green: 145/255, blue: 143/255, alpha: 1), for: .normal)
        bttn.titleLabel?.font = UIFont(name: "FiraSans-Medium", size: 18)
        bttn.addTarget(self, action: #selector(continueButtonClicked), for: .touchUpInside)
        return bttn
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 82/255, green: 78/255, blue: 78/255, alpha: 0.5)
        addSubViews()
        setupConstraints()
    }
    
    private func addSubViews() {
        view.addSubview(alertView)
        
        alertView.addSubview(titleLabel)
        alertView.addSubview(messageLabel)
        alertView.addSubview(continueButton)
    }
    
    private func setupConstraints() {
        
        alertView.snp.makeConstraints { (make) in
            make.centerX.centerY.equalToSuperview()
            make.width.equalTo(280)
            make.height.equalTo(140)
        }
        
        messageLabel.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.right.equalToSuperview().inset(24)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.bottom.equalTo(messageLabel.snp.top).offset(-10)
            make.left.equalToSuperview().inset(24)
        }
        
        continueButton.snp.makeConstraints { (make) in
            make.right.bottom.equalToSuperview().inset(8)
        }
        
    }
    
    @objc private func continueButtonClicked() {
        
    }
}

// MARK: - SwiftUI
import SwiftUI

struct FinishAlertVCProvider: PreviewProvider {
    
    static var previews: some View {
        return ContentView()
    }
    
    struct ContentView: UIViewControllerRepresentable {
        
        func makeUIViewController(context: Context) -> FinishAlertViewController {
            return FinishAlertViewController()
        }
        
        func updateUIViewController(_ uiViewController: FinishAlertViewController, context: Context) {
            //
        }
    }
}
