//
//  PostSendRequest.swift
//  FastPost
//
//  Created by Murat Merekov on 13.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import UIKit

class PostSendRequestViewController: UIViewController {
    
    private lazy var imageView: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "textIm")
        return image
    }()
    
    private lazy var calendarButton: UIButton = {
        let bttn = UIButton()
        bttn.setImage(UIImage(named: "Calendar"), for: .normal)
        return bttn
    }()
    
//    private lazy var recomendedLabel: UILabel = {
//        let label = UILabel()
//        label.text = "Возможно, вам подойдут эти маршруты"
//        label.font = UIFont(name: "FiraSans-Bold", size: 15)
//        label.textColor = UIColor(red: 114/255, green: 146/255, blue: 169/255, alpha: 1)
//        return label
//    }()
    
    private lazy var fromCityTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Откуда"
        text.cornerRadius = 25
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
        return text
    }()
    
    private lazy var toCityTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Куда"
        text.cornerRadius = 25
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
        return text
    }()
    
    private lazy var dateTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Дата"
        text.cornerRadius = 25
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4.0
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
        return text
    }()
    
    private lazy var weightTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Обьем"
        text.cornerRadius = 25
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4.0
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
        return text
    }()
    
    private lazy var descriptionTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Описание, примечания"
        text.cornerRadius = 10
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4.0
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, -80, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
        return text
    }()
    
    private lazy var transportTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Транспорт"
        text.cornerRadius = 25
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4.0
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.tag = 1
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
//        let vc = TransportTypeViewController()
//        text.inputAccessoryView
        text.delegate = self
        return text
    }()
    
    private lazy var priceTextField: UITextField = {
        let text = UITextField()
        text.placeholder = "Цена"
        text.cornerRadius = 25
        text.font = UIFont(name: "FiraSans-Medium", size: 14)
        text.clipsToBounds = false
        text.backgroundColor = UIColor.white
        text.layer.shadowRadius = 4.0
        text.layer.borderColor = UIColor.gray.cgColor
        text.layer.shadowColor = UIColor.gray.cgColor
        text.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        text.layer.shadowOpacity = 0.3
        text.layer.sublayerTransform = CATransform3DMakeTranslation(20, 0, 0)
        text.textColor = UIColor.black
        text.translatesAutoresizingMaskIntoConstraints = false
        return text
    }()
    
    private lazy var publishRequestButoon: UIButton = {
        let bttn = UIButton()
        bttn.setTitle("Оставить заявку", for: .normal)
        bttn.titleLabel?.font = UIFont(name: "FiraSans-Bold", size: 14)
        bttn.setTitleColor(.white, for: .normal)
        bttn.cornerRadius = 20
        bttn.clipsToBounds = false
        bttn.backgroundColor = UIColor(red: 35/255, green: 104/255, blue: 152/255, alpha: 1)
        bttn.layer.shadowRadius = 4.0
        
        bttn.layer.shadowColor = UIColor.gray.cgColor
        bttn.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        bttn.layer.shadowOpacity = 0.3
        bttn.translatesAutoresizingMaskIntoConstraints = false
        bttn.addTarget(self, action: #selector(publishButtonClicked), for: .touchUpInside)
        return bttn
    }()
    
    private lazy var verticalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .vertical
        stk.spacing = 10
        stk.distribution = .fillProportionally
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var horizontalDateAndWeightStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .horizontal
        stk.spacing = 10
        stk.distribution = .fillEqually
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    private lazy var horizontalTransportAndPriceStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .horizontal
        stk.spacing = 10
        stk.distribution = .fillEqually
        stk.translatesAutoresizingMaskIntoConstraints = false
        return stk
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        addSubViews()
        setupConstraints()
        
    }
    
    private func addSubViews() {
        
        view.addSubview(verticalStackView)
        view.addSubview(imageView)
        
        
        dateTextField.addSubview(calendarButton)
        
        horizontalDateAndWeightStackView.addArrangedSubview(dateTextField)
        horizontalDateAndWeightStackView.addArrangedSubview(weightTextField)
        
        horizontalTransportAndPriceStackView.addArrangedSubview(transportTextField)
        horizontalTransportAndPriceStackView.addArrangedSubview(priceTextField)
        
        verticalStackView.addArrangedSubview(fromCityTextField)
        verticalStackView.addArrangedSubview(toCityTextField)
        verticalStackView.addArrangedSubview(horizontalDateAndWeightStackView)
        verticalStackView.addArrangedSubview(horizontalTransportAndPriceStackView)
        verticalStackView.addArrangedSubview(descriptionTextField)
        verticalStackView.addArrangedSubview(publishRequestButoon)
        
    }
    
    private func setupConstraints() {
        
        imageView.snp.makeConstraints { (make) in
            make.top.equalTo(60)
            make.left.equalTo(30)
        }
        
        descriptionTextField.snp.makeConstraints { (make) in
            make.height.equalTo(140)
        }
        
        verticalStackView.snp.makeConstraints { (make) in
            make.top.equalTo(imageView).inset(30)
            make.left.equalToSuperview().inset(15)
            make.right.equalToSuperview().inset(15)
            make.height.equalTo(500)
        }
        
        fromCityTextField.snp.makeConstraints { (make) in
            make.height.equalTo(50)
        }
        
        toCityTextField.snp.makeConstraints { (make) in
            make.height.equalTo(50)
        }
        
        horizontalDateAndWeightStackView.snp.makeConstraints { (make) in
            make.height.equalTo(50)
        }
        horizontalTransportAndPriceStackView.snp.makeConstraints { (make) in
            make.height.equalTo(50)
        }
        
//        recomendedLabel.snp.makeConstraints { (make) in
//            make.top.equalTo(verticalStackView.snp.bottom).offset(20)
//            make.left.equalToSuperview().inset(30)
//        }
        
        publishRequestButoon.snp.makeConstraints { (make) in
            make.height.equalTo(40)
        }
        
        calendarButton.snp.makeConstraints { (make) in
            make.right.equalTo(dateTextField.snp.right).offset(-40)
            make.centerY.equalToSuperview()
        }
        
    }
    
    @objc private func publishButtonClicked() {
        let vc = FinishAlertViewController()
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overCurrentContext
        self.present(vc, animated: true)
    }
}

extension PostSendRequestViewController: UITextFieldDelegate{
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        let vc = TransportTypeViewController()
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overCurrentContext
        self.present(vc, animated: true)
        return false
    }
}

// MARK: - SwiftUI
import SwiftUI

struct PostSendRequestVCProvider: PreviewProvider {
    
    static var previews: some View {
        return ContentView()
    }
    
    struct ContentView: UIViewControllerRepresentable {
        
        func makeUIViewController(context: Context) -> PostSendRequestViewController {
            return PostSendRequestViewController()
        }
        
        func updateUIViewController(_ uiViewController: PostSendRequestViewController, context: Context) {
            //
        }
    }
}
