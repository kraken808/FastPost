//
//  TransportTypeViewController.swift
//  FastPost
//
//  Created by Murat Merekov on 14.05.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import UIKit
import SnapKit

class TransportTypeViewController: UIViewController {
    
    private lazy var visibleView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.cornerRadius = 10
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var carTickButton: UIButton = {
        let bttn = UIButton()
        bttn.layer.borderWidth = 1.5
        bttn.layer.borderColor = CGColor(srgbRed: 114/255, green: 146/255, blue: 169/255, alpha: 0.75)
        bttn.setImage(UIImage(named: "Selected"), for: .normal)
        bttn.addTarget(self, action: #selector(carTickButtonClicked), for: .touchUpInside)
        bttn.tag = 0
        return bttn
    }()
    
    private lazy var busTickButton: UIButton = {
        let bttn = UIButton()
        bttn.layer.borderWidth = 1.5
        bttn.layer.borderColor = CGColor(srgbRed: 114/255, green: 146/255, blue: 169/255, alpha: 0.75)
        bttn.setImage(UIImage(named: "Selected"), for: .normal)
        bttn.addTarget(self, action: #selector(busTickButtonClicked), for: .touchUpInside)
        bttn.tag = 0
        return bttn
    }()
    
    private lazy var trainTickButton: UIButton = {
        let bttn = UIButton()
        bttn.layer.borderWidth = 1.5
        bttn.layer.borderColor = CGColor(srgbRed: 114/255, green: 146/255, blue: 169/255, alpha: 0.75)
        bttn.addTarget(self, action: #selector(trainTickButtonClicked), for: .touchUpInside)
        bttn.setImage(UIImage(named: "Selected"), for: .normal)
        bttn.tag = 0
        return bttn
    }()
    
    private lazy var planeTickButton: UIButton = {
        let bttn = UIButton()
        bttn.layer.borderWidth = 1.5
        bttn.layer.borderColor = CGColor(srgbRed: 114/255, green: 146/255, blue: 169/255, alpha: 0.75)
        bttn.addTarget(self, action: #selector(planeTickButtonClicked), for: .touchUpInside)
        bttn.setImage(UIImage(named: "Selected"), for: .normal)
        bttn.tag = 0
        return bttn
    }()
    
    private lazy var transportLabel: UILabel = {
        let label = UILabel()
        label.text = "Транспорт"
        label.font = UIFont(name: "FiraSans-Bold", size: 18)
        label.textColor = UIColor(red: 247/255, green: 145/255, blue: 143/255, alpha: 1)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var okButton: UIButton = {
        let bttn = UIButton()
        bttn.setTitle("OK", for: .normal)
        bttn.setTitleColor(UIColor(red: 247/255, green: 145/255, blue: 143/255, alpha: 1), for: .normal)
        bttn.titleLabel?.font = UIFont(name: "FiraSans-Bold", size: 18)
        bttn.addTarget(self, action: #selector(okButtonClicked), for: .touchUpInside)
        return bttn
    }()
    
    private lazy var busLabel: UILabel = {
        let label = UILabel()
        label.text = "Транспорт"
        label.font = UIFont(name: "FiraSans-Medium", size: 16)
        label.textColor = UIColor(red: 0.137, green: 0.408, blue: 0.596, alpha: 1)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var carLabel: UILabel = {
        let label = UILabel()
        label.text = "Автомобиль"
        label.font = UIFont(name: "FiraSans-Medium", size: 16)
        label.textColor = UIColor(red: 0.137, green: 0.408, blue: 0.596, alpha: 1)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var trainLabel: UILabel = {
        let label = UILabel()
        label.text = "Поезд"
        label.font = UIFont(name: "FiraSans-Medium", size: 16)
        label.textColor = UIColor(red: 0.137, green: 0.408, blue: 0.596, alpha: 1)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var planeLabel: UILabel = {
        let label = UILabel()
        label.text = "Самолет"
        label.font = UIFont(name: "FiraSans-Medium", size: 16)
        label.textColor = UIColor(red: 0.137, green: 0.408, blue: 0.596, alpha: 1)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private lazy var busHorizontalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .horizontal
        stk.spacing = 10
        stk.distribution = .fill
        return stk
    }()
    
    private lazy var carHorizontalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .horizontal
        stk.spacing = 10
        stk.distribution = .fill
        return stk
    }()
    
    private lazy var trainHorizontalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .horizontal
        stk.spacing = 10
        stk.distribution = .fill
        return stk
    }()
    
    private lazy var planeHorizontalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .horizontal
        stk.spacing = 10
        stk.distribution = .fill
        return stk
    }()
    
    private lazy var verticalStackView: UIStackView = {
        let stk = UIStackView()
        stk.alignment = .fill
        stk.axis = .vertical
        stk.spacing = 12
        stk.distribution = .fillEqually
        return stk
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 82/255, green: 78/255, blue: 78/255, alpha: 0.5)
        addSubviews()
        setupConstraints()
        
    }
    
    private func addSubviews() {
        view.addSubview(visibleView)
        
        busHorizontalStackView.addArrangedSubview(busTickButton)
        busHorizontalStackView.addArrangedSubview(busLabel)
        
        carHorizontalStackView.addArrangedSubview(carTickButton)
        carHorizontalStackView.addArrangedSubview(carLabel)
        
        trainHorizontalStackView.addArrangedSubview(trainTickButton)
        trainHorizontalStackView.addArrangedSubview(trainLabel)
        
        planeHorizontalStackView.addArrangedSubview(planeTickButton)
        planeHorizontalStackView.addArrangedSubview(planeLabel)
        
        verticalStackView.addArrangedSubview(busHorizontalStackView)
        verticalStackView.addArrangedSubview(carHorizontalStackView)
        verticalStackView.addArrangedSubview(trainHorizontalStackView)
        verticalStackView.addArrangedSubview(planeHorizontalStackView)
        
        visibleView.addSubview(verticalStackView)
        visibleView.addSubview(transportLabel)
        visibleView.addSubview(okButton)
        
    }
    
    private func setupConstraints(){
        visibleView.snp.makeConstraints { (make) in
            make.centerX.centerY.equalToSuperview()
            make.height.equalTo(240)
            make.width.equalTo(280)
        }
        
        busTickButton.snp.makeConstraints { (make) in
            make.height.width.equalTo(20)
        }
        carTickButton.snp.makeConstraints { (make) in
            make.height.width.equalTo(20)
        }
        trainTickButton.snp.makeConstraints { (make) in
            make.height.width.equalTo(20)
        }
        planeTickButton.snp.makeConstraints { (make) in
            make.height.width.equalTo(20)
        }
        
        verticalStackView.snp.makeConstraints { (make) in
            make.height.equalTo(115)
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().inset(50)
        }
        
        transportLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(24)
            make.bottom.equalTo(verticalStackView.snp.top).offset(-15)
        }
        
        okButton.snp.makeConstraints { (make) in
            make.right.bottom.equalToSuperview().inset(8)
        }
    }
    
    @objc private func carTickButtonClicked() {
        if carTickButton.tag == 0{
            carTickButton.backgroundColor = UIColor(red: 247/255, green: 145/255, blue: 143/255, alpha: 1)
            carTickButton.tag = 1
        } else {
            carTickButton.backgroundColor = .white
            carTickButton.tag = 0
        }
    }
    
    @objc private func busTickButtonClicked() {
        if busTickButton.tag == 0{
            busTickButton.backgroundColor = UIColor(red: 247/255, green: 145/255, blue: 143/255, alpha: 1)
            busTickButton.tag = 1
        } else {
            busTickButton.backgroundColor = .white
            busTickButton.tag = 0
        }
    }
    
    @objc private func trainTickButtonClicked() {
        if trainTickButton.tag == 0{
            trainTickButton.backgroundColor = UIColor(red: 247/255, green: 145/255, blue: 143/255, alpha: 1)
            trainTickButton.tag = 1
        } else {
            trainTickButton.backgroundColor = .white
            trainTickButton.tag = 0
        }
    }
    
    @objc private func planeTickButtonClicked() {
        if planeTickButton.tag == 0{
            planeTickButton.backgroundColor = UIColor(red: 247/255, green: 145/255, blue: 143/255, alpha: 1)
            planeTickButton.tag = 1
        } else {
            planeTickButton.backgroundColor = .white
            planeTickButton.tag = 0
        }
    }
    
    @objc private func okButtonClicked() {
        self.dismiss(animated: false, completion: nil)
    }
}

// MARK: - SwiftUI
import SwiftUI

struct TransportTypeVCProvider: PreviewProvider {

static var previews: some View {
        return ContentView()
    }
    
    struct ContentView: UIViewControllerRepresentable {
        
        func makeUIViewController(context: Context) -> TransportTypeViewController {
            return TransportTypeViewController()
        }
        
        func updateUIViewController(_ uiViewController: TransportTypeViewController, context: Context) {
            //
        }
    }
}
