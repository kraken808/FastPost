//
//  ViewController.swift
//  FastPost
//
//  Created by Murat Merekov on 26.04.2021.
//  Copyright © 2021 Murat Merekov. All rights reserved.
//

import UIKit
import SnapKit

class SplashScreenViewController: UIViewController {

    private lazy var imageView: UIImageView = {
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 150, height: 150))
        imageView.image = UIImage(named: "FastPostIcon")
        return imageView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addSubViews()
        setupConstraints()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        DispatchQueue.main.asyncAfter(deadline: .now()+1) {
            self.animate()
        }
    }
    
    private func addSubViews(){
        view.addSubview(imageView)
    }

    private func setupConstraints(){
        imageView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
        }
    }
    
    private func animate(){
        UIView.animate(withDuration: 2) {
            let size = self.view.frame.size.width * 3
            let diffX = size - self.view.frame.size.width
            let diffY = self.view.frame.size.height - size
            
            self.imageView.frame = CGRect(x: -(diffX/2),
                                          y: diffY/2,
                                          width: size,
                                          height: size)
        }
        
        UIView.animate(withDuration: 1.5, animations: {
            self.imageView.alpha = 0
        }) { (done) in
            if done {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    let gotoVC = ChooseViewController()
                    gotoVC.modalTransitionStyle = .crossDissolve
                    gotoVC.modalPresentationStyle = .fullScreen
                    self.present(gotoVC, animated: true)
                }
                
            }
        }
        
    }
    
}

